CREATE DATABASE  IF NOT EXISTS `sproj` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `sproj`;
-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: localhost    Database: sproj
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `user_id` varchar(30) NOT NULL,
  `twitter_handle` varchar(15) NOT NULL,
  `rank` int DEFAULT NULL,
  `popularity_rating` int DEFAULT NULL,
  `total_followers` int DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES ('1015965765940498434','Seventeen_Mile',67,43,300),('1076991893207080960','PainCapital',50,46,43),('108021761','valuewalk',23,56,57771),('1154108616212963330','HardcoreValue',85,41,31),('1289436835','UnionSquareGrp',24,55,6720),('1364930179','WarrenBuffett',58,45,1642438),('1373568355','DumbLuckCapital',36,49,7350),('14173032','marketfolly',9,65,50253),('14230772','matt_levine',79,42,99129),('142742259','HowardWPenney',92,40,11263),('14276189','herbgreenberg',21,57,382868),('1431342590','CopperfieldRscr',89,40,6122),('1469603575','QTRResearch',78,42,103001),('1473023792','EdBorgato',51,46,13460),('1484632920','LadyFOHF',55,45,11298),('15003446','John_Hempton',1,79,42942),('1534167900','Carl_C_Icahn',12,64,383601),('1631140573','SIRF_Report',17,57,12402),('163537857','MicroFundy',45,48,8541),('16598957','firstadopter',57,45,38106),('168679374','muddywatersre',3,73,121130),('18223590','footnoted',30,53,21137),('182642157','DavidSchawel',39,49,41090),('191690478','plainview_',75,42,3456),('1942560164','DennyCrane550',66,43,1178),('1961333743','WallStCynic',19,57,40499),('20636215','LongShortTrader',13,63,27012),('211951561','HedgeyeENERGY',87,41,11508),('21241717','schaudenfraud',98,39,5528),('2149782648','FundyLongShort',34,50,4793),('2151247592','BrattleStCap',6,67,19446),('2177224099','FatTailCapital',28,54,12320),('2188619364','Keubiko',48,47,15028),('223238349','AlderLaneeggs',4,71,38592),('2235043482','TigreCapital',88,40,1903),('2236826372','EventDrivenMgr',10,64,8113),('22522178','ReformedBroker',26,55,1110931),('2281127150','probesreporter',63,44,8232),('232120274','Jesse_Livermore',49,47,60325),('2347247707','SmallCapLS',52,45,3770),('236953420','CitronResearch',5,68,138918),('2371952437','sprucepointcap',15,62,26584),('241583523','GlaucusResearch',84,41,8903),('2426574114','ActivistShorts',11,64,21507),('2432549275','marginalidea',47,47,2940),('2471879203','Fritz844',74,42,5114),('25073877','realDonaldTrump',60,45,76815926),('2525906341','BluegrassCap',16,59,34087),('25410160','UnderwaterCap',96,39,2864),('260943149','xuexishenghuo',61,44,3419),('2615610961','cablecarcapital',62,44,6332),('26223938','BergenCapital',46,48,28053),('2626671050','jay_21_',97,39,2093),('267317705','adoxen',91,40,5049),('2803822165','DonutShorts',14,62,22634),('28571999','bespokeinvest',95,40,88191),('286654612','mark_dow',100,39,71933),('2960231085','nosunkcosts',44,48,4933),('3044346069','StaleyRdCap',68,43,5391),('3108351','WSJ',59,45,17584581),('31186367','PlanMaestro',25,55,18397),('319102548','fundiescapital',41,48,4930),('3195244375','NoonSixCap',18,57,13589),('33747430','AlexRubalcava',54,45,8987),('342251338','SkeleCap',27,54,9152),('34713362','business',65,44,6207141),('34939208','BarbarianCap',2,76,33242),('35499699','ActAccordingly',42,48,6659),('355866075','modestproposal1',8,65,50337),('35770843','manualofideas',77,42,21183),('358482230','FCFYield',83,41,6799),('39199749','Hedge_FundGirl',37,49,6569),('40243607','TMTanalyst',76,42,12277),('40909981','PhilipEtienne',86,41,9656),('411034263','AZ_Value',82,41,5500),('4464995894','AureliusValue',69,43,17301),('45690518','EquityNYC',43,48,4685),('472600930','ShortSightedCap',29,53,8897),('486139568','KerrisdaleCap',7,65,33457),('52849759','davidein',71,43,47289),('560294989','JacobWolinsky',32,51,5877),('573356661','Find_Me_Value',70,43,13183),('5943622','pmarca',40,49,740632),('633238141','mjmauboussin',93,40,59787),('702585281','LibertyRPF',81,41,9979),('807025762708688898','RodBoydILM',53,45,8893),('820534716','JohnHuber72',99,39,18916),('851632189','GrantsPub',64,44,38935),('861619895485726722','TruthGundlach',94,40,125880),('884935388','PresciencePoint',38,49,15135),('915557073496285185','MugatuCapital',35,50,0),('955733059','GothamResearch',20,57,24064),('961797541','activiststocks',56,45,8815);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-20 13:09:47
